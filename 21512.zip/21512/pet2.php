<?php
require_once('db_config.php');

$host = "localhost";
$username = "test";
$password = "123456";
$database = "menagerie";
$conn = mysqli_connect($host, $username, $password, $database);

if (!$conn) {
    die("連線失敗：" . mysqli_connect_error());
}
mysqli_set_charset($conn, "utf8");

// 如果有從表單送出新增資料，就先處理 INSERT
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    $name    = $_POST['name'];
    $owner   = $_POST['owner'];
    $species = $_POST['species'];
    $sex     = $_POST['sex'];
    $birth   = $_POST['birth'];
    $death   = $_POST['death'];

    // 簡單版：直接組 SQL（教學用，正式環境建議用 prepared statement）
    $sql_insert = "
        INSERT INTO pet (name, owner, species, sex, birth, death)
        VALUES ('$name', '$owner', '$species', '$sex', '$birth', '$death')
    ";
    mysqli_query($conn, $sql_insert);

    // 新增完重新整理頁面，避免重新整理瀏覽器時重複送出表單
    header("Location: pet_list.php"); // 把 pet_list.php 換成你這支檔案的真實檔名
    exit;
}

// 讀出全部資料顯示
$sql = "SELECT name, owner, species, sex, birth, death FROM pet";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>寵物名單 - 可新增</title>
</head>
<body>

    <h2>獸醫院：寵物紀錄表</h2>

    <!-- 顯示現有資料 -->
    <table width="100%" border="1" cellspacing="0" cellpadding="8">
        <tr>
            <th>Name</th>
            <th>Owner</th>
            <th>Species</th>
            <th>Sex</th>
            <th>Birth</th>
            <th>Death</th>
        </tr>

        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
        <tr>
            <td><?php echo htmlspecialchars($row['name']); ?></td>
            <td><?php echo htmlspecialchars($row['owner']); ?></td>
            <td><?php echo htmlspecialchars($row['species']); ?></td>
            <td><?php echo htmlspecialchars($row['sex']); ?></td>
            <td><?php echo htmlspecialchars($row['birth']); ?></td>
            <td><?php echo htmlspecialchars($row['death']); ?></td>
        </tr>
        <?php } ?>
    </table>

    <hr>

    <!-- 新增一筆資料的表單 -->
    <h3>新增寵物資料</h3>
    <form method="post">
        <!-- 用 hidden 來區分是新增動作 -->
        <input type="hidden" name="action" value="add">

        <p>
            Name：
            <input type="text" name="name" required>
        </p>
        <p>
            Owner：
            <input type="text" name="owner" required>
        </p>
        <p>
            Species：
            <input type="text" name="species" required>
        </p>
        <p>
            Sex：
            <input type="text" name="sex" maxlength="1">
            <!-- 例如 M / F，可以自己改成下拉選單 -->
        </p>
        <p>
            Birth：
            <input type="date" name="birth" required>
        </p>
        <p>
            Death：
            <input type="date" name="death">
        </p>

        <p>
            <button type="submit">新增</button>
        </p>
    </form>

</body>
</html>