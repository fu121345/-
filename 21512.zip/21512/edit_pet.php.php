<?php
require_once('db_config.php');

$host = "localhost";
$username = "test";
$password = "123456";
$database = "menagerie";
$conn = mysqli_connect($host, $username, $password, $database);

if (!$conn) {
    die("連線失敗：" . mysqli_connect_error());
}
mysqli_set_charset($conn, "utf8");

// 1. 取得網址列上的 id
if (!isset($_GET['id'])) {
    die("沒有指定要編輯的資料 id");
}
$id = (int)$_GET['id'];

// 2. 如果有送出表單，就更新資料
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name    = $_POST['name'];
    $owner   = $_POST['owner'];
    $species = $_POST['species'];
    $sex     = $_POST['sex'];
    $birth   = $_POST['birth'];
    $death   = $_POST['death'];

    $sql_update = "
        UPDATE pet
        SET name    = '$name',
            owner   = '$owner',
            species = '$species',
            sex     = '$sex',
            birth   = '$birth',
            death   = '$death'
        WHERE id = $id
    ";
    mysqli_query($conn, $sql_update);

    // 更新完導回列表頁
    header("Location: pet_list.php"); // 檔名改成你的列表頁檔名
    exit;
}

// 3. 先查出這一筆原本的資料，顯示在表單裡
$sql  = "SELECT * FROM pet WHERE id = $id";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);

if (!$row) {
    die("找不到這筆資料");
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>修改寵物資料</title>
</head>
<body>

    <h2>修改寵物資料（ID：<?php echo $row['id']; ?>）</h2>

    <form method="post">
        <p>
            Name：
            <input type="text" name="name" value="<?php echo htmlspecialchars($row['name']); ?>" required>
        </p>
        <p>
            Owner：
            <input type="text" name="owner" value="<?php echo htmlspecialchars($row['owner']); ?>" required>
        </p>
        <p>
            Species：
            <input type="text" name="species" value="<?php echo htmlspecialchars($row['species']); ?>" required>
        </p>
        <p>
            Sex：
            <input type="text" name="sex" value="<?php echo htmlspecialchars($row['sex']); ?>" maxlength="1">
        </p>
        <p>
            Birth：
            <input type="date" name="birth" value="<?php echo htmlspecialchars($row['birth']); ?>" required>
        </p>
        <p>
            Death：
            <input type="date" name="death" value="<?php echo htmlspecialchars($row['death']); ?>">
        </p>

        <p>
            <button type="submit">儲存修改</button>
            <a href="pet_list.php">取消，回列表</a>
        </p>
    </form>

</body>
</html>