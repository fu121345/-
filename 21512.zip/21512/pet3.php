<?php
require_once('db_config.php');

$host = "localhost";
$username = "test";
$password = "123456";
$database = "menagerie";
$conn = mysqli_connect($host, $username, $password, $database);

if (!$conn) {
    die("連線失敗：" . mysqli_connect_error());
}
mysqli_set_charset($conn, "utf8");

// 如果有從表單送出新增資料，就先處理 INSERT
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    $name    = $_POST['name'];
    $owner   = $_POST['owner'];
    $species = $_POST['species'];
    $sex     = $_POST['sex'];
    $birth   = $_POST['birth'];
    $death   = $_POST['death'];

    $sql_insert = "
        INSERT INTO pet (name, owner, species, sex, birth, death)
        VALUES ('$name', '$owner', '$species', '$sex', '$birth', '$death')
    ";
    mysqli_query($conn, $sql_insert);

    header("Location: pet_list.php"); // 檔名請改成你實際的列表檔案名稱
    exit;
}

// 讀出全部資料顯示（包含 id）
$sql = "SELECT id, name, owner, species, sex, birth, death FROM pet";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>寵物名單 - 可新增與修改</title>
</head>
<body>

    <h2>獸醫院：寵物紀錄表</h2>

    <!-- 顯示現有資料 -->
    <table width="100%" border="1" cellspacing="0" cellpadding="8">
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Owner</th>
            <th>Species</th>
            <th>Sex</th>
            <th>Birth</th>
            <th>Death</th>
            <th>操作</th>
        </tr>

        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
        <tr>
            <td><?php echo $row['id']; ?></td>
            <td><?php echo htmlspecialchars($row['name']); ?></td>
            <td><?php echo htmlspecialchars($row['owner']); ?></td>
            <td><?php echo htmlspecialchars($row['species']); ?></td>
            <td><?php echo htmlspecialchars($row['sex']); ?></td>
            <td><?php echo htmlspecialchars($row['birth']); ?></td>
            <td><?php echo htmlspecialchars($row['death']); ?></td>
            <td>
                <a href="edit_pet.php?id=<?php echo $row['id']; ?>">修改</a>
            </td>
        </tr>
        <?php } ?>
    </table>

    <hr>

    <!-- 新增一筆資料的表單 -->
    <h3>新增寵物資料</h3>
    <form method="post">
        <input type="hidden" name="action" value="add">

        <p>
            Name：
            <input type="text" name="name" required>
        </p>
        <p>
            Owner：
            <input type="text" name="owner" required>
        </p>
        <p>
            Species：
            <input type="text" name="species" required>
        </p>
        <p>
            Sex：
            <input type="text" name="sex" maxlength="1">
        </p>
        <p>
            Birth：
            <input type="date" name="birth" required>
        </p>
        <p>
            Death：
            <input type="date" name="death">
        </p>

        <p>
            <button type="submit">新增</button>
        </p>
    </form>

</body>
</html>